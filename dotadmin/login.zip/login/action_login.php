<?php
include('../config/config.php');
if(isset($_POST['login'])){
   $user = mysql_real_escape_string(htmlentities($_POST['username']));
   $pass = mysql_real_escape_string(htmlentities(md5($_POST['password'])));
 
   $sql = mysql_query("SELECT * FROM user WHERE username='$user' AND password='$pass'") or die(mysql_error());
   if(mysql_num_rows($sql) == 0){
      echo 'User tidak ditemukan';
      header('location:index.php');
   }else{
      $row = mysql_fetch_assoc($sql);
      if($row['kode_userRole'] == 1){
         $_SESSION['1']=$row;
         echo '<script language="javascript">alert("Anda berhasil Login Admin!"); document.location="../admin/index.php";</script>';
      }else{
         $_SESSION['2']=$row;
         echo '<script language="javascript">alert("Anda berhasil Login user!"); document.location="../user/index.php";</script>';
      }
   }
}
?>