<!-- Footer -->
      <section id="footer">
        <div class="container">
          <header class="major">
            <h2>Contact US</h2>
          </header>
          <div class="col-md-15">
            <p> +62 821 2400 5713 (Bill) <br/>
                +62 811 363 9411 (Arya) <br/>
                +62 341 435 9716 (Malang Office) <br/>
                +62 21 428 030 08 (Jakarta Office) </p>
                </div>
          <form method="post" action="#">
            <div class="row uniform">
              <div class="6u 12u$(xsmall)"><input type="text" name="name" id="name" placeholder="Name" /></div>
              <div class="6u$ 12u$(xsmall)"><input type="email" name="email" id="email" placeholder="Email" /></div>
              <div class="12u$"><textarea name="message" id="message" placeholder="Message" rows="4"></textarea></div>
              <div class="12u$">
                <ul class="actions">
                  <li><input type="submit" value="Send Message" class="special" /></li>
                </ul>
              </div>
            </div>
          </form>
        </div>
        <footer>
          <ul class="icons">
            <li><a href="#" class="icon alt fa-twitter"><span class="label">Twitter</span></a></li>
            <li><a href="#" class="icon alt fa-facebook"><span class="label">Facebook</span></a></li>
            <li><a href="#" class="icon alt fa-instagram"><span class="label">Instagram</span></a></li>
            <li><a href="#" class="icon alt fa-dribbble"><span class="label">Dribbble</span></a></li>
            <li><a href="#" class="icon alt fa-envelope"><span class="label">Email</span></a></li>
          </ul>
          <ul class="copyright">
            <li>&copy; Untitled</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li><li>Demo Image: <a href="http://unsplash.com">Unsplash</a></li>
          </ul>
        </footer>
      </section>