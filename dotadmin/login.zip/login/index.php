<?php include("../config/config.php");?>
<?php include 'head.php'; ?>
<?php include 'content.php'; ?>
<?php include 'footer.php'; ?>
<?php include 'jslogin.php'; ?>